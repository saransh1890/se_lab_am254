
import pytest
from student_grades import letter_grade, final_marks, exam_eligibility


# LETTER GRADE TESTS

def test_invalid_negative_marks():
    with pytest.raises(ValueError):
        letter_grade(-1)


def test_invalid_marks_above_100():
    with pytest.raises(ValueError):
        letter_grade(101)


def test_all_grades():
    assert letter_grade(95) == "S"
    assert letter_grade(85) == "A"
    assert letter_grade(75) == "B"
    assert letter_grade(65) == "C"
    assert letter_grade(55) == "D"
    assert letter_grade(45) == "E"
    assert letter_grade(30) == "F"


# FINAL MARKS TESTS

def test_invalid_internal_marks():
    with pytest.raises(ValueError):
        final_marks(41, 50, False)


def test_final_marks_without_project():
    assert final_marks(30, 40, False) == 70


def test_final_marks_with_project():
    assert final_marks(30, 40, True) == 75


def test_final_marks_capped_at_100():
    assert final_marks(40, 60, True) == 100


# EXAM ELIGIBILITY TESTS

def test_fees_not_paid():
    assert exam_eligibility(80, False, False) == "blocked"


def test_attendance_75_or_more():
    assert exam_eligibility(80, True, False) == "eligible"


def test_medical_eligibility():
    assert exam_eligibility(70, True, True) == "eligible"


def test_low_attendance():
    assert exam_eligibility(60, True, False) == "detained"
