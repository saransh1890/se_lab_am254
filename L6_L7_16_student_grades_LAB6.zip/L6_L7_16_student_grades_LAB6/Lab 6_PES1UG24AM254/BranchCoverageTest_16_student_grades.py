
import pytest
from student_grades import letter_grade, final_marks, exam_eligibility


# LETTER GRADE - BRANCH TESTS

def test_letter_grade_all_boundaries():
    assert letter_grade(100) == "S"
    assert letter_grade(90) == "S"
    assert letter_grade(89) == "A"
    assert letter_grade(80) == "A"
    assert letter_grade(79) == "B"
    assert letter_grade(70) == "B"
    assert letter_grade(69) == "C"
    assert letter_grade(60) == "C"
    assert letter_grade(59) == "D"
    assert letter_grade(50) == "D"
    assert letter_grade(49) == "E"
    assert letter_grade(40) == "E"
    assert letter_grade(39) == "F"


def test_letter_grade_negative_marks():
    with pytest.raises(ValueError):
        letter_grade(-1)


def test_letter_grade_marks_above_100():
    with pytest.raises(ValueError):
        letter_grade(101)


# FINAL MARKS - BRANCH TESTS

def test_internal_marks_exceed_limit():
    with pytest.raises(ValueError):
        final_marks(41, 50, False)


def test_external_marks_exceed_limit():
    with pytest.raises(ValueError):
        final_marks(30, 61, False)


def test_valid_marks_without_project():
    assert final_marks(30, 40, False) == 70


def test_valid_marks_with_project():
    assert final_marks(30, 40, True) == 75


def test_project_marks_exceed_100():
    assert final_marks(40, 60, True) == 100


def test_project_marks_do_not_exceed_100():
    assert final_marks(35, 55, True) == 95


# EXAM ELIGIBILITY - BRANCH TESTS

def test_fees_not_paid():
    assert exam_eligibility(90, False, True) == "blocked"


def test_attendance_above_75():
    assert exam_eligibility(80, True, False) == "eligible"


def test_attendance_exactly_75():
    assert exam_eligibility(75, True, False) == "eligible"


def test_medical_approval():
    assert exam_eligibility(70, True, True) == "eligible"


def test_no_medical_approval():
    assert exam_eligibility(70, True, False) == "detained"


def test_attendance_below_65():
    assert exam_eligibility(60, True, True) == "detained"
