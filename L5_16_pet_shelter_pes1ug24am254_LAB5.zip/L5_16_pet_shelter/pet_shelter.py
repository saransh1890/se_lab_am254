
"""Manage pet shelter registrations, adoptions, and availability."""

import secrets
import sqlite3


class PetShelter:
    """Store pet records and manage shelter adoption operations."""

    def __init__(self):
        """Initialize the in-memory database and adoption counter."""
        self.conn = sqlite3.connect(":memory:")
        self.conn.execute(
            """
            CREATE TABLE pets (
                id INTEGER PRIMARY KEY,
                name TEXT,
                species TEXT,
                age INTEGER,
                adopted INTEGER
            )
            """
        )
        self.adoption_count = 0

    def register_pet(self, name, species, age, tags=None):
        """Register a pet and return its updated list of tags."""
        if tags is None:
            tags = []

        self.conn.execute(
            """
            INSERT INTO pets (name, species, age, adopted)
            VALUES (?, ?, ?, 0)
            """,
            (name, species, age),
        )
        tags.append(species)
        return tags

    def adopt(self, pet_id):
        """Mark a pet as adopted and update the adoption counter."""
        cursor = self.conn.execute(
            "UPDATE pets SET adopted = 1 WHERE id = ? AND adopted = 0",
            (pet_id,),
        )
        if cursor.rowcount > 0:
            self.adoption_count += 1

    def adoption_code(self):
        """Generate a four-digit adoption code."""
        return f"PET-{secrets.randbelow(9000) + 1000}"

    def oldest_available(self):
        """Return the name of the oldest available pet, if one exists."""
        row = self.conn.execute(
            """
            SELECT name
            FROM pets
            WHERE adopted = 0
            ORDER BY age DESC, id ASC
            LIMIT 1
            """
        ).fetchone()

        if row is None:
            return None
        return row[0]

    def clear_unadopted(self):
        """Remove all pets that have not been adopted."""
        self.conn.execute("DELETE FROM pets WHERE adopted = 0")

    def shelter_status(self):
        """Return the shelter status based on adoption activity."""
        if self.adoption_count > 0:
            return "active"
        return "quiet"

    def close(self):
        """Close the database connection."""
        self.conn.close()


def main():
    """Run a demonstration of the pet shelter operations."""
    shelter = PetShelter()

    try:
        shelter.register_pet("Bruno", "dog", 7)
        shelter.register_pet("Mitzi", "cat", 3)
        shelter.register_pet("Kiwi", "parrot", 12)

        shelter.adopt(1)

        print(
            shelter.oldest_available(),
            shelter.adoption_code(),
            shelter.shelter_status(),
        )

        shelter.clear_unadopted()
    finally:
        shelter.close()


if __name__ == "__main__":
    main()
