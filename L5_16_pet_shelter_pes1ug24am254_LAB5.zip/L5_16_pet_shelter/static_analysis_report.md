\# Lab 5: Static Code Analysis



\## 1. Objective



The objective of this lab was to improve the quality, security, readability, and maintainability of the `pet\_shelter.py` program using Pylint, Bandit, and Flake8.



\## 2. Tools Used



\- \*\*Pylint:\*\* Detects code-quality problems, naming violations, missing documentation, and potential programming errors.

\- \*\*Bandit:\*\* Identifies common security vulnerabilities in Python code.

\- \*\*Flake8:\*\* Detects formatting and style violations based on Python coding conventions.



\## 3. Issues Identified and Fixes Applied



| Issue | Tool | Description | Fix applied |

|---|---|---|---|

| Mutable default argument | Pylint | A list was used as a default argument, which could be shared between calls. | Replaced the mutable default with `None` and initialized the list inside the function. |

| Invalid function names | Pylint | Several function names used camelCase instead of snake\_case. | Renamed functions to follow Python naming conventions. |

| Missing docstrings | Pylint | Functions lacked descriptive documentation. | Added docstrings describing their purpose. |

| Global statement | Pylint | Global state made the program harder to maintain. | Encapsulated shelter state in a class. |

| Broad exception handling | Pylint | Broad or bare exception handlers can hide unexpected errors. | Removed unnecessary broad exception handling. |

| SQL injection risk | Bandit | Constructing SQL statements using string formatting can allow untrusted input to alter a query. | Used parameterized SQL queries. |

| Insecure random-number generation | Bandit | The standard `random` module is not intended for security-sensitive values. | Used the `secrets` module to generate adoption codes. |

| Long lines | Flake8 | Several lines exceeded the recommended 79-character limit. | Reformatted long statements across multiple lines. |

| Multiple statements on one line | Flake8 | Multiple statements on a single line reduced readability. | Separated statements onto individual lines. |

| Mixed line endings | Pylint | The source file contained inconsistent newline formats. | Standardized the file's line endings. |



\## 4. Before-and-After Results



| Tool | Before | After |

|---|---|---|

| Pylint | 3.95/10 | 10.00/10 |

| Bandit | 3 findings: 2 low and 1 medium severity | 0 findings |

| Flake8 | 5 reported violations | No violations reported |



\## 5. Verification



The updated Python program was executed to verify its basic operation. The static analysis tools were then run again against the updated source file.



The final Pylint score was 10.00/10, exceeding the required score of 9.5. Bandit reported no issues, and the Flake8 after-report was empty.



\## 6. Reflection



\### Q1. What is static code analysis?



Static code analysis examines source code without executing the program. It helps developers identify potential bugs, security vulnerabilities, and coding-style violations early in development.



\### Q2. What are the differences between Pylint, Bandit, and Flake8?



Pylint focuses on code quality and programming practices. Bandit checks for common security vulnerabilities. Flake8 focuses on style and formatting violations.



\### Q3. Why are parameterized SQL queries important?



Parameterized queries keep SQL instructions separate from supplied values. This helps prevent SQL injection and makes database operations safer.



\### Q4. What problems can mutable default arguments cause?



A mutable default argument, such as an empty list, may be reused across multiple function calls. This can cause unintended data sharing. Using `None` and creating a new list inside the function avoids this problem.



\### Q5. How did static analysis improve the program?



The analysis process helped identify security risks, inconsistent naming, missing documentation, exception-handling problems, and formatting violations. Fixing these issues improved readability, maintainability, and security.



\### Q6. What did you learn from this lab?



I learned that a program can run successfully while still containing security and maintainability problems. Using multiple static analysis tools provides complementary checks and helps improve code quality systematically.



\## 7. Conclusion



The lab demonstrated how Pylint, Bandit, and Flake8 can be used together to improve a Python program. The updated `pet\_shelter.py` achieved a Pylint score of 10.00/10, Bandit reported no findings, and Flake8 reported no violations. The before-and-after reports provide evidence of the improvements.



