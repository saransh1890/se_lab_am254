import re


def average_marks(marks_csv):
    if not isinstance(marks_csv, str):
        raise ValueError("Marks must be a CSV string.")

    parts = marks_csv.split(",")

    if any(not p.strip() for p in parts):
        raise ValueError("Marks cannot be empty.")

    try:
        marks = [int(p.strip()) for p in parts]
    except ValueError:
        raise ValueError("Marks must contain integers only.")

    if any(mark < 0 or mark > 100 for mark in marks):
        raise ValueError("Marks must be between 0 and 100.")

    return round(sum(marks) / len(marks), 2)


def parse_srn(srn):
    if not isinstance(srn, str):
        raise ValueError("SRN must be a string.")

    pattern = r"^[A-Z]{3}\\dUG\\d{2}[A-Z]{2}\\d{3}$"

    if not re.fullmatch(pattern, srn):
        raise ValueError("Invalid SRN format.")

    return srn[:4], int(srn[6:8]), srn[8:10]


def short_name(full_name):
    if not isinstance(full_name, str):
        raise ValueError("Name must be a string.")

    parts = full_name.split()

    if len(parts) != 2:
        raise ValueError("Enter first name and last name.")

    first, last = parts
    return first[0].upper() + ". " + last.capitalize()


def main():
    print("==== Running average_marks ====")
    user_input = input("Enter marks as CSV (e.g. 78,85,92): ")
    try:
        print("Average Marks:", average_marks(user_input))
    except ValueError as e:
        print("Error:", e)

    print("\n==== Running parse_srn ====")
    user_input = input("Enter an SRN (e.g. PES1UG23CS123): ")
    try:
        print("Campus, Year and Dept:", parse_srn(user_input))
    except ValueError as e:
        print("Error:", e)

    print("\n==== Running short_name ====")
    user_input = input("Enter first and last name (e.g. ravi kumar): ")
    try:
        print("Short Name:", short_name(user_input))
    except ValueError as e:
        print("Error:", e)


if __name__ == "__main__":
    main()
