Lab 7 submission - Student Grades

Student: Saransh Mittal
SRN: PES1UG24AM254

Contents:
- student_grades.py: fixed application
- test_student_grades.py: Hypothesis tests
- Lab7_Report.pdf: report with supplied screenshots
- screenshots/: four screenshots supplied in the conversation

Run:
python -m pip install hypothesis pytest
python -m pytest test_student_grades.py -v
python student_grades.py
