from hypothesis import given, strategies as st
from student_grades import average_marks, parse_srn, short_name


# Average marks fuzz test
@given(st.one_of(st.text(), st.none()))
def test_average_marks_no_crash(s):
    try:
        result = average_marks(s)
        assert 0 <= result <= 100
    except ValueError:
        pass


@given(st.lists(st.integers(min_value=0, max_value=100),
                min_size=1, max_size=20))
def test_average_marks_correct(marks):
    csv = ",".join(map(str, marks))
    expected = round(sum(marks) / len(marks), 2)
    assert average_marks(csv) == expected


# SRN fuzz test
@given(st.one_of(st.text(), st.none()))
def test_parse_srn_no_crash(s):
    try:
        result = parse_srn(s)
        assert isinstance(result, tuple)
        assert len(result) == 3
    except ValueError:
        pass


@given(
    st.integers(min_value=0, max_value=99),
    st.sampled_from(["AM", "CS", "EC", "ME"])
)
def test_parse_srn_correct(year, dept):
    srn = f"PES1UG{year:02d}{dept}254"
    assert parse_srn(srn) == ("PES1", year, dept)


# Short name fuzz test
@given(st.one_of(st.text(), st.none()))
def test_short_name_no_crash(s):
    try:
        result = short_name(s)
        assert isinstance(result, str)
    except ValueError:
        pass


@given(
    st.text(alphabet="abcdefghijklmnopqrstuvwxyz",
            min_size=1, max_size=15),
    st.text(alphabet="abcdefghijklmnopqrstuvwxyz",
            min_size=1, max_size=15)
)
def test_short_name_correct(first, last):
    expected = first[0].upper() + ". " + last.capitalize()
    assert short_name(first + " " + last) == expected
