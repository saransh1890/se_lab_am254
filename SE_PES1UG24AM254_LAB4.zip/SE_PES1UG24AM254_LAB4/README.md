# Lab 4 — VibeCoding: Hangman Challenge

**Student:** Saransh Mittal  
**SRN:** PES1UG24AM254

## Project files
- `main.py` — application entry point.
- `game.py` — game logic, difficulty, scoring, hints, input handling and session flow.
- `words.py` — in-memory words and hints.
- `stats.py` — in-memory session statistics.
- `requirements.txt` — dependency declaration.

## Run
Python 3.9 or newer is recommended. The project uses only the standard library.

```bash
python main.py
```

## Implemented tasks
### Task 1 — Guess-state correctness
- Correct and incorrect guesses are both remembered.
- Repeated guesses do not consume another life.
- Letter input is normalized to lowercase.

### Task 2 — Session statistics
- Tracks completed rounds, wins and best winning streak.
- Statistics persist across rounds in one session.
- An unfinished round exited with `/quit` is not counted.

### Task 3 — Difficulty and scoring
- Easy: 8 lives and 5 base points.
- Medium: 6 lives and 10 base points.
- Hard: 4 lives and 15 base points.
- Winning adds the current streak as a bonus.
- A hint deducts 2 points, with the score floored at zero.
- Difficulty can be selected for each round.

### Task 4 — Robust input and feedback
- Rejects invalid, multi-character and non-letter guesses.
- Handles invalid category and difficulty choices.
- Gives clear feedback for repeated guesses and repeated hint use.
- Supports quitting from category selection, difficulty selection and gameplay.
- Validates the replay response.

## Submission evidence to add
Add the two required 10-second recordings before final submission:
- `before_hangman.mp4` — original game showing the repeated-wrong-guess bug.
- `after_hangman.mp4` — updated game showing the fix and added features.

Also include the complete LLM chat-history link or export required by the lab handout.

## Testing
Run the required checks from the assignment README, including repeated correct and incorrect guesses, hints, category changes, multiple rounds, streak resets, difficulty changes, invalid input and quitting.
