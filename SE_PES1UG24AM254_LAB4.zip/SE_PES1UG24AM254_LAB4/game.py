import random
from words import WORDS, HINTS
from stats import SessionStats


class HangmanGame:
    DIFFICULTIES = {
        "easy": {"lives": 8, "points": 5},
        "medium": {"lives": 6, "points": 10},
        "hard": {"lives": 4, "points": 15},
    }

    def __init__(self):
        self.score = 0
        self.streak = 0
        self.category = "technology"
        self.difficulty = "medium"
        self.secret = ""
        self.guessed = set()
        self.wrong = set()
        self.lives = 6
        self.hint_used = False
        self.stats = SessionStats()

    def start_round(self):
        self.secret = random.choice(WORDS[self.category])
        self.guessed.clear()
        self.wrong.clear()
        self.lives = self.DIFFICULTIES[self.difficulty]["lives"]
        self.hint_used = False

    def masked(self):
        return " ".join(
            ch if ch in self.guessed else "_"
            for ch in self.secret
        )

    def won(self):
        return all(ch in self.guessed for ch in set(self.secret))

    def guess(self, letter):
        letter = letter.strip().lower()
        if len(letter) != 1 or not letter.isalpha():
            return "Invalid input. Enter exactly one letter."
        if letter in self.guessed or letter in self.wrong:
            return "You have already guessed that letter."
        if letter in self.secret:
            self.guessed.add(letter)
            return "Correct! The letter is in the word."
        self.wrong.add(letter)
        self.lives -= 1
        return "Wrong! Try another letter."

    def use_hint(self):
        if self.hint_used:
            return "You have already used your hint this round."
        self.hint_used = True
        self.score = max(0, self.score - 2)
        hint = HINTS.get(self.secret)
        if hint is None:
            return "Sorry, no hint is available for this word."
        return f"Hint: {hint} (2 points deducted)"

    def choose_category(self):
        print("\nAvailable categories:", ", ".join(WORDS))
        while True:
            raw = input("Choose category or q to quit: ").strip().lower()
            if raw == "q":
                return False
            if raw not in WORDS:
                print("Invalid category. Please choose an available category.")
                continue
            self.category = raw
            return True

    def choose_difficulty(self):
        print("\nChoose difficulty:")
        print("1. Easy (8 lives, 5 base points)")
        print("2. Medium (6 lives, 10 base points)")
        print("3. Hard (4 lives, 15 base points)")
        choices = {
            "1": "easy", "2": "medium", "3": "hard",
            "easy": "easy", "medium": "medium", "hard": "hard",
        }
        while True:
            choice = input("Enter difficulty or q to quit: ").strip().lower()
            if choice == "q":
                return False
            if choice not in choices:
                print("Invalid difficulty. Choose Easy, Medium, or Hard.")
                continue
            self.difficulty = choices[choice]
            print("Selected difficulty:", self.difficulty.title())
            return True

    def play_round(self):
        self.start_round()
        print(f"\nStarting {self.difficulty.title()} round!")
        while self.lives > 0 and not self.won():
            print("\nWord:", self.masked())
            print("Wrong:", " ".join(sorted(self.wrong)) or "-")
            print("Lives:", self.lives, "Score:", self.score, "Streak:", self.streak)
            raw = input("Letter, /hint, or /quit: ").strip().lower()
            if raw == "/quit":
                return False
            if raw == "/hint":
                print(self.use_hint())
                continue
            print(self.guess(raw))

        if self.won():
            self.streak += 1
            base_points = self.DIFFICULTIES[self.difficulty]["points"]
            bonus_points = self.streak
            earned = base_points + bonus_points
            self.score += earned
            print("Solved:", self.secret)
            print("Base points:", base_points)
            print("Streak bonus:", bonus_points)
            print("Points earned:", earned)
            self.stats.record(True, self.streak)
            return True

        self.streak = 0
        print("Out of lives. The word was:", self.secret)
        self.stats.record(False, self.streak)
        return True

    def show_session_stats(self):
        print("\n========== SESSION STATISTICS ==========")
        print("Rounds played:", self.stats.rounds)
        print("Rounds won:", self.stats.wins)
        print("Best streak:", self.stats.best_streak)
        print("Final score:", self.score)
        print("========================================")

    def run(self):
        print("Hangman Challenge")
        print("A session consists of multiple rounds.")
        while True:
            if not self.choose_category():
                self.show_session_stats()
                return
            if not self.choose_difficulty():
                self.show_session_stats()
                return
            if not self.play_round():
                self.show_session_stats()
                return
            while True:
                again = input("\nAnother round? [y/n]: ").strip().lower()
                if again in ("y", "n"):
                    break
                print("Invalid input. Please enter y or n.")
            if again == "n":
                self.show_session_stats()
                return


if __name__ == "__main__":
    HangmanGame().run()
